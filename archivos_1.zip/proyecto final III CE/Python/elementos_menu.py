#Diccionario con todos los items del menú con sus características (descripción, precio, tiempo, categoría)
menu_de_pollo = [
    {'descripcion': 'pollo asado', 'precio': 200, 'tiempo': 20, 'categoria':'PTF'},
    {'descripcion': 'pollo frito', 'precio': 150, 'tiempo': 15, 'categoria': 'PTF'},
    {'descripcion': 'pollo rostisado', 'precio': 180, 'tiempo': 30, 'categoria': 'PTF'},
    {'descripcion': 'pollo a la plancha', 'precio': 120, 'tiempo': 15, 'categoria': 'PTF'},
    {'descripcion': 'alitas de pollo', 'precio': 220, 'tiempo': 25, 'categoria': 'PTF'},
    {'descripcion': 'limonada', 'precio': 30, 'tiempo': 0, 'categoria': 'BBD'},
    {'descripcion': 'te frio', 'precio': 25, 'tiempo': 0, 'categoria': 'BBD'},
    {'descripcion': 'cerveza', 'precio': 60, 'tiempo': 0, 'categoria': 'BBD'},
    {'descripcion': 'jamaica', 'precio': 40, 'tiempo': 0, 'categoria': 'BBD'},
    {'descripcion': 'horchata', 'precio': 50, 'tiempo': 0, 'categoria': 'BBD'},
    {'descripcion': 'pay de manzana', 'precio': 115, 'tiempo': 10, 'categoria': 'PST'},
    {'descripcion': 'pay de limon', 'precio': 100, 'tiempo': 10, 'categoria': 'PST'},
    {'descripcion': 'pastel de chocolate', 'precio': 90, 'tiempo': 10, 'categoria': 'PST'},
    {'descripcion': 'flan casero', 'precio': 120, 'tiempo': 10, 'categoria': 'PST'},
    {'descripcion': 'helado de coco', 'precio': 80, 'tiempo': 10, 'categoria': 'PST'},
]



